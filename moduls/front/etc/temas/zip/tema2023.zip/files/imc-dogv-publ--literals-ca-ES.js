// Document JavaScript


// descaonnecta

var txtDesconnectaTitol = "Eixir de l'aplicació"
	,txtDesconnectaText = "Està segur de voler desconnectar?";


// form validació

var txtFormErrorTitol = "Error al camp "
	,txtFormErrorText = "Aquest camp ha d'estar complimentat.";


// form desa

var txtFormGuardarTitol = "Desant les dades..."
	,txtFormGuardarText = "Espere un moment, per favor.";


// form valida

var txtErrorAlCamp = "Error al camp"
	,txtErrorAlCampInfo = "Aquest camp ha d'estar complimentat."
	,txtErrorAlCampAny = "L'any no és correcte"
	,txtErrorAlCampImport = "L'import no és correcte"
	,txtErrorAlCampCIF = "El número CIF no és correcte";


// input file

var txtInputFileCapSeleccionat = "No hi ha cap element seleccionat."
	,txtInputFileElimina = "Elimina arxiu"
	,txtInputFileDescarrega = "Descarrega l'arxiu"
	,txtInputFileRetorna = "Retorna a l'arxiu anterior"
	,txtArxiuEsborraTitol = "Està segur d'esborrar aquest arxiu?"
	,txtArxiuEsborraText = "Si ho fa, no podrà recuperar-la."
	,txtArxiuEsborraCorrecteTitol = "L'axiu s'ha esborrat correctament"
	,txtIncidenciaDesaCorrecteTitol = "L'incidència s'ha guardat correctament";

var txtInputFileTipus = "Els documents permesos són: "
	,txtInputFileMida = "La mida màxima és: "
	,txtInputFileVisualitza = "Visualitza"
	,txtInputFileVisualitzaTitol = "Visualitza document PDF"
	,txtInputDocAnnexat = "Hi ha un document annexat";


// peu disposició

var mesos_val_de = ["de", "de", "de", "d'", "de", "de", "de", "d'", "de", "de", "de", "de"]
	,mesos_cas_de = ["de", "de", "de", "de", "de", "de", "de", "de", "de", "de", "de", "de"];

var mesos_val = ["Gener", "Febrer", "Març", "Abril", "Maig", "Juny", "Juliol", "Agost", "Setembre", "Octubre", "Novembre", "Decembre"]
	,mesos_cas = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Setiembre", "Octubre", "Noviembre", "Diciembre"];


/* avisos */

var txtAvisMarcaComLlegit = "Marcar com llegit"
	,txtAvisMarcaComNoLlegit = "Marcar com no llegit"


/* missatgeria */

var txtContestacio = "Contestació"
	,txtNouMissatge = "Nou missatge";


/* afectacion */

var txtAfectacioDesvinculaTitol = "Està segur de voler desvincular la diposició?"
	,txtAfectacioDesvinculaCorrecte = "Hem desvinculat la disposició amb l'id: ";

var txtAfectacioGuardaTitol = "Vol guardar l'afectació?"
	,txtAfectacioGuardaCorrecteTitol = "Hem guardat l'afectació!"


/* desplegables */

var txtPlega = "Plega opcions"
	,txtDesplega = "Desplega opcions";


// tesauros

var txtSeleccionatCap = "Cap element seleccionat."
	,txtSeleccionats = "Seleccionats "
	,txtDescriptors = " descriptors."
	,txtFiltrats = " filtrats, de "
	,txtEnTotal = " en total."
	,txtMostrats = "Mostrats "
	,txtElements = " elements"
	,txtObriSubmenu = "Obri submenú"
	,txtElimina = "Elimina";

var txtTermesRelacionats = "Temes relacionats"
	,txtTermesRelacionatsAbbr = "T.r."
	,txtTermesEquivalents = "Temes equivalents"
	,txtTermesEquivalentsAbbr = "T.e.";

var txtSinonimEsborraTitol = "Està segur d'esborrar aquest sinònim?"
	,txtSinonimEsborraText = "Si ho fa, no podrà recuperar-ho."
	,txtSinonimEsborraCorrecteTitol = "El sinònim s'ha esborrat correctament"
	,txtSinonimNou = "Nou sinònim"
	,txtSinonimEdita = "Edita sinònim";

var txtNotaEsborraTitol = "Està segur d'esborrar aquesta nota?"
	,txtNotaEsborraText = "Si ho fa, no podrà recuperar-la."
	,txtNotaEsborraCorrecteTitol = "la nota s'ha esborrat correctament";

var txtNoHiHaMicrotesauros = "No hi ha microtesauros."
	,txtNoHiHaTermesFills = "No hi ha termes fills."


// cercador plegable

var txtInfoSeleccionatsValors = "Estan seleccionats els següents valors: "
	,txtInfoCapSeleccionat = "Es mostren tots els resultats. No hi ha seleccionat cap valor de cerca."
	,txtCercadorBotoMostra = "Mostra opcions de cerca"
	,txtCercadorBotoAmaga = "Amaga opcions de cerca";


// dates

var txtDesDe = "des de"
	,txtFinsA = "fins a";


// sumari

var txtDisposicioMou = "Mou disposició"
	,txtDisposicioPosicio = "Posició";