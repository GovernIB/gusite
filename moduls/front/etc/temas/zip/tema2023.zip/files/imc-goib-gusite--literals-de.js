// Document JavaScript


// desconnecta

var txtDesconnectaTitol = "Salir de la aplicación"
	,txtDesconnectaText = "Está seguro que quiere desconectarse?";


// form validació -> imc-goib-gusite--app-ux-form.js

var txtForm_campObligatori = "Este campo es obligatorio"
	,txtForm_error_campCorreu = "Este campo ha de ser un correo electrónico"
	,txtForm_error_campPagina = "Este campo ha de ser una página web";

var txtForm_error_JS_titol = "Error en el campo "
	,txtForm_error_JS_text = "Este campo se ha de rellenar";


// missatge -> imc-goib-gusite--app-ux-missatge.js

var txtAccepta = "Aceptar"
	,txtCancela = "Cancelar"
	,txtDacord = "De acuerdo";

//imatges -> imc-goib-gusite--app-pag-galeria-imatges.js

var txtImatge = "Bilder";
