// Document JavaScript


// desconnecta

var txtDesconnectaTitol = "Sortir de l'aplicació"
	,txtDesconnectaText = "Està segur de voler desconnectar?";


// form validació -> imc-goib-gusite--app-ux-form.js

var txtForm_campObligatori = "Aquest camp és obligatori"
	,txtForm_error_campCorreu = "Aquest camp ha de ser un correu electrònic"
	,txtForm_error_campPagina = "Aquest camp ha de ser una pàgina web";

var txtForm_error_JS_titol = "Error al camp "
	,txtForm_error_JS_text = "Aquest camp ha d'estar complimentat.";


// missatge -> imc-goib-gusite--app-ux-missatge.js

var txtAccepta = "Accepta"
	,txtCancela = "Cancel·la"
	,txtDacord = "D'acord";

//imatges -> imc-goib-gusite--app-pag-galeria-imatges.js

var txtImatge = "imatges";

