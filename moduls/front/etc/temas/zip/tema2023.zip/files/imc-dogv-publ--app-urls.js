// Document JavaScript


// ESTATIC

var APP_SERVIDOR_ESTATIC = "https://localhost/gva/dogv/portal/";



// URLS 

var URL_INDEX = "index.html"
	,URL_DISPOSICIO_FITXA = "pag_disposicio_fitxa.html";



// BBDD

var APP_SERVIDOR = "https://localhost/gva/dogv/publicacions/servidor/bbdd/";


// tesauros

var APP_TESAURO_ORGANISMES = APP_SERVIDOR + "tesauro_organismes.php"
	,APP_TESAURO_ORGANISMES_HTML = APP_SERVIDOR_ESTATIC + "html/tesauro_organismes.html";

var APP_TESAURO_GEOGRAFIC = APP_SERVIDOR + "tesauro_geografic.php"
	,APP_TESAURO_GEOGRAFIC_HTML = APP_SERVIDOR_ESTATIC + "html/tesauro_geografic.html";

var APP_ORGANS_EMISORS = APP_SERVIDOR + "organs_emisors.php"
	,APP_ORGANS_EMISORS_HTML = APP_SERVIDOR_ESTATIC + "html/organs_emisors.html";

var APP_TESAURO_TEMATIC = APP_SERVIDOR + "tesauro_tematic.php"
	,APP_TESAURO_TEMATIC_HTML = APP_SERVIDOR_ESTATIC + "html/tesauro_tematic.html";


